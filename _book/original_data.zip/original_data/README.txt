Speech Emotion Recognition Voice Dataset

Original source: https://www.kaggle.com/datasets/tapakah68/emotions-on-audio-dataset/data

Content
files: includes folders corresponding to people and containing text spoken in English in 4 different manners: euphoric, joyfully, sad and surprised
.csv file: contains information about people in the dataset


File with the extension .csv
includes the following information for each set of media files:

set_id: link to the set of audio files,
text: text spoken in the audio set,
gender: gender of the person,
age: age of the person,
country: country of the person


Sources
The data was collected by our team.

Collection Methodology
The files were provided by users that passed the test. These data were validated by in-house reviewers.

License
Attribution-NonCommercial-NoDerivatives 4.0 International (CC BY-NC-ND 4.0)